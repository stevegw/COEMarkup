// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


console.log($scope.app);

//
// ******************************************************************
// Globals 
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


//
// ******************************************************************
// local functions
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//
// The output from the session images is an InfoTable but unfortunately when bound to a datgrid the columns editor is not exposed
//

BuildList = function() {
  
  var imagesData = $scope.view.wdg["dataGridSessionImages"].data.rows;
   try {

     imagesData.sort((a, b) => b.date - a.date);
      var index = 1;
      Object.keys(imagesData).forEach(function(item){ 
        
        if (index < 6 )  {
        $scope.view.wdg['image-' +index].imgsrc =   imagesData[item].image; 
        index++;
          
        } 

      }); 
     
   } catch(ex) {
     console.log ("Possible Error: When trying to work through images Data data passed Exception:"+ex);
   }
  
}

  
UploadTWXService = function () {
  
  
  
    var img = $scope.view.wdg['imageForUpload'].imgsrc;
    var contentArray = img.split(',');

    var TWXmodelID = 'FE_RWTakePhoto_Repo';

    var serviceName = 'UploadPhoto';

    var parameters = {'details':  $scope.view.wdg['textAreaDetails'].text , 'imageContent': contentArray[1] };  

    twx.app.fn.triggerDataService(TWXmodelID, serviceName, parameters);

}



//
// ******************************************************************
// Event methods
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//



$scope.$on('UploadPhoto.serviceInvokeComplete', function(evt, arg) {

    $scope.resetUI();

});


//
// ******************************************************************
// Studio Exposed Methods
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//


$scope.resetUI = function () {
  
  $scope.view.wdg['bottomPopup'].visible = true;
  $scope.view.wdg['showListPopup'].visible = true;
  $scope.view.wdg['draftsPopup'].visible = true;
  $scope.view.wdg['popupUpload'].visible = false;  
  
}

$scope.UploadSelected = function () {
  
  $scope.postQuickMessage("Uploading");
  UploadTWXService();
  
}
  
  



$scope.postQuickMessage = function (message) {
  twx.app.fn.addSnackbarMessage(message);
}

$scope.markupCompleted = function() {
  
  BuildList();

  $timeout(function() {
      $scope.resetUI();
   }, 500); 

}


$scope.showSelectedImage = function (me) {
  
  $scope.view.wdg['imageForUpload'].imgsrc = $scope.view.wdg[me.widgetName].imgsrc;
  $scope.view.wdg['bottomPopup'].visible = false;
  $scope.view.wdg['showListPopup'].visible = false;
  $scope.view.wdg['draftsPopup'].visible = false;
  $scope.view.wdg['popupUpload'].visible = true;  
}


