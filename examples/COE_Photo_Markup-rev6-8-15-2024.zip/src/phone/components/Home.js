// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


console.log($scope.app);

//
// ******************************************************************
// Globals 
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


//
// ******************************************************************
// local functions
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//
// The output from the session images is an InfoTable but unfortunately when bound to a datgrid the columns editor is not exposed
//

BuildList = function() {
  
  var imagesData = $scope.view.wdg["dataGridSessionImages"].data.rows;
   try {

      var index = 1;
      Object.keys(imagesData).forEach(function(item){ 
        
        if (index < 6 )  {
        $scope.view.wdg['image-' +index].imgsrc =   imagesData[item].image; 
        index++;
          
        } 

      }); 
     
   } catch(ex) {
     console.log ("Possible Error: When trying to work through images Data data passed Exception:"+ex);
   }
  
}

  


//
// ******************************************************************
// Event methods
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//


/*$scope.$on('UploadPhoto.serviceInvokeComplete', function(evt, arg) {

   // done something in code if required

});*/



$scope.$on('UploadPhoto.serviceInvokeComplete', function(evt, arg) {

   // done something in code if required

});


//
// ******************************************************************
// Studio Exposed Methods
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//


$scope.UploadSelected = function () {
  
  $scope.postQuickMessage("Uploading");


}
  
  



$scope.postQuickMessage = function (message) {
  twx.app.fn.addSnackbarMessage(message);
}

$scope.markupCompleted = function() {
  
  $scope.postQuickMessage("Markup Completed");
  $timeout(function() {
   BuildList();
   }, 500); 

}


$scope.showSelectedImage = function (me) {
  
  $scope.view.wdg['imageForUpload'].imgsrc = $scope.view.wdg[me.widgetName].imgsrc;
  $scope.view.wdg['popupUpload'].visible = true;
  
}


