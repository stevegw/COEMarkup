// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available




$scope.postQuickMessage = function (message) {
  
  twx.app.fn.addSnackbarMessage(message);
  
}


$scope.showMarkup = function () {
  
  
  
  
}